﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQIntroduction
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"c:\windows";

            ShowLargeFilesWithLinq(path);
            Console.ReadKey();
        }

        private static void ShowLargeFilesWithLinq(string path)
        {
            var query = from file in new DirectoryInfo(path).GetFiles()
                        orderby file.Length
                        select file;

            var query1 = new DirectoryInfo(path).GetFiles()
                           .OrderByDescending(f => f.Length)
                           .Take(5);

            foreach (var file in query)
            {
                Console.WriteLine($"{file.Name,-30}: {file.Length,10:N0}");
            }
        }
    }
}
